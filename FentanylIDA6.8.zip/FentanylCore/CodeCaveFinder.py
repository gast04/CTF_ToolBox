import idaapi, idc

'''
try:
    from PySide import QtGui as Gui
    from PySide import QtCore as Core
except ImportError:
    print "PySide unavailable, no GUI"
    Core = None
    Gui = None
'''
class CodeCaveWindow(idaapi.PluginForm):
    def findCodeCavez(self, segment=".text"):
        start = idc.SegByBase(idc.SegByName(segment))
        if start == idc.BADADDR:
            print "Can't find segment %s\n" % (segment)
            return

        end = idc.SegEnd(start)
        print "[*] Start code cave scaning from 0x%x to 0x%x\n" % (start, end)
        curr_addr = start
        curr_size = 0
        biggest_addr = idc.BADADDR
        biggest_size = 0
        results = []
        while start < end:
            #new_addr = idc.FindText(start + curr_size, idc.SEARCH_DOWN | idc.SEARCH_NEXT | idc.SEARCH_REGEX, 0, 0, "align 4")
            new_addr = idc.FindBinary(start, idc.SEARCH_DOWN | idc.SEARCH_NEXT, "00")
            print "[*] New Address : 0x%x" % new_addr
            if start == new_addr:
                break
            curr_size = idc.ItemSize(new_addr)
            if curr_size > biggest_size:
                biggest_addr = new_addr
                biggest_size = curr_size
                results.append((new_addr, curr_size))
            start = new_addr
        return results
        return biggest_addr, biggest_size

    def findCodeCavez2(self, segment=".text"):
        start = idc.SegByBase(idc.SegByName(segment))
        if start == idc.BADADDR:
            print "Can't find segment %s\n" % (segment)
            return

        end = idc.SegEnd(start)
        print "[*] Start code cave scaning from 0x%x to 0x%x\n" % (start, end)
        curr_addr = start
        curr_size = 0
        biggest_addr = idc.BADADDR
        biggest_size = 0
        results = []
        while start < end:
            new_addr = idc.FindBinary(start, idc.SEARCH_DOWN | idc.SEARCH_NEXT, "00 00 00 00 00 00 00 00")
            print "[*] New Address : 0x%x" % new_addr
            if start == new_addr:
                break
            skip = new_addr
            while idaapi.get_byte(skip) == 0:
                skip = skip + 1

            curr_size = skip - new_addr
            if curr_size > biggest_size:
                biggest_addr = new_addr
                biggest_size = curr_size
                results.append((new_addr, curr_size))
            start = skip
        return results
        return biggest_addr, biggest_size

    def addEntryToTree(self, segment, address, size):
        from PySide import QtGui
        entry = QtGui.QTreeWidgetItem(self.tree)
        entry.setText(0, segment)
        entry.setText(1, "0x%x"%(address))
        entry.setText(2, ("%d"%(size)).zfill(10))
        # print dir(entry)

    def PopulateTree(self):
        self.tree.clear()
        executable_segments = [(idc.SegName(idaapi.getnseg(x).startEA), 0!=(idaapi.getnseg(x).perm & idaapi.SEGPERM_EXEC)) for x in range(idaapi.get_segm_qty())]
        for segment in executable_segments:
            if not segment[1]:
                continue
            caves = self.findCodeCavez2(segment[0])
            for cave in caves:
                self.addEntryToTree(segment[0], cave[0], cave[1])

    def OnCreate(self, form):
        from PySide import QtGui
        self.parent = self.FormToPySideWidget(form)
        self.tree = QtGui.QTreeWidget()
        self.tree.setHeaderLabels(("Segment","Address","Size"))
        self.tree.setColumnWidth(0, 100)
        self.tree.setSortingEnabled(True)
        layout = QtGui.QVBoxLayout()
        layout.addWidget(self.tree)

        jump = QtGui.QPushButton("Jump To")
        jump.clicked.connect(self.jump)
        layout.addWidget(jump)

        search_again = QtGui.QPushButton("Go Spelunking")
        search_again.clicked.connect(self.PopulateTree)
        layout.addWidget(search_again)

        # self.PopulateTree()
        self.parent.setLayout(layout)

    def jump(self):
        current_item = self.tree.currentItem()
        if current_item:
            idc.Jump(int(current_item.text(1)[2:], 16))
