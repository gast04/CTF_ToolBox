"""
FtlHooks.py

Hooks to process various events.

"""

import idaapi

class FtlHooks(idaapi.UI_Hooks):
    def __init__(self):
        #print "[*] Fentanyl FtlHooks Init ..."
        super(FtlHooks, self).__init__()
        self.hooks = {}
        self.cmd = None

    def preprocess(self, name):
        #print "[*] Fentanyl FtlHook preprocess ..."
        self.cmd = name
        return 0

    def postprocess(self):
    	#print "[*] Fentanyl FtlHook postprocess..."
        if self.cmd in self.hooks:
            self.hooks[self.cmd]() #call function
        return 0
        
    def register(self, name, func):
        #print ("[*] Fentanyl FtlHook register function : %s" % name)
        self.hooks[name] = func

    def unregister(self, name):
        #print ("[*] Fentanyl FtlHook unregister function : %s" % name)
        self.hooks[name] = None


