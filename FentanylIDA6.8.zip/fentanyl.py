"""
main.py

IDAPython script to patch binaries. 

IDAPython: https://code.google.com/p/idapython/
Helfpul if you want to run scripts on startup: https://code.google.com/p/idapython/source/browse/trunk/examples/idapythonrc.py

Alt F7 to load scripts

File > Produce file > Create DIF file
Edit > Patch program > Apply patches to input file

Keybindings:
    Shift-N: Convert instruction to nops
    Shift-X: Nop all xrefs to this function
    Shift-J: Invert conditional jump
    Shift-U: Make jump unconditional
    Shift-P: Patch instruction
    Shift-Z: Undo modification (Won't always work. Should still be careful editing.)
    Shift-Y: Redo modification (Won't always work. Should still be careful editing.)

"""


import idaapi, idautils, idc
from idaapi import Form, Choose2, plugin_t
import os, re, string
import random

if not idaapi.is_idaq():
    exit()

from FentanylCore import *
from FentanylCore.ActionHandler import ActionHandler

try:
    from PySide import QtGui
    from PySide import QtCore
except ImportError:
    print "[Fentanyl] PySide unavailable, no GUI !"
    QtCore = None
    QtGui = None

#Interfaces to the methods in ftl
def nopout():
    global ftl
    start, end = Utils.get_pos()
    ftl.nopout(start, end - start)

import traceback
def m_assemble():
    #try: assemble_()
    #except e:
    #    print traceback.format_exc()
    assemble_()

def assemble_():
    global asf, ftl
    success = False
    while not success:
        v = asf.process()
        if not v or not v['inp'].strip(): 
            print "[*] fentanyl assemble init not success ...\n"
            return

        start, end = Utils.get_pos()
        lines = [i.strip() for i in v['inp'].replace(';', '\n').strip().split('\n')]
        success, data = ftl.assemble(start, lines, v['opt_chk']['fixup'], v['opt_chk']['nopout'])

        if not success:
            print data

def togglejump():
    global ftl
    start, end = Utils.get_pos()
    ftl.togglejump(start)

def uncondjump():
    global ftl
    start, end = Utils.get_pos()
    ftl.uncondjump(start)

def nopxrefs():
    global ftl
    start, end = Utils.get_pos()
    func = idaapi.get_func(start)
    if func:
        ftl.nopxrefs(func.startEA)

def undo():
    global ftl
    if ftl.undo() is None:
        print "Nothing to undo"

def redo():
    global ftl
    if ftl.redo() is None:
        print "Nothing to redo"

def fentanyl_savefile():
    output_file = AskFile(1, "*", "Save patched file.")
    if not output_file:
        return
    Utils.save_file(output_file)

#Interface to spelunky
def openspelunky():
    window = CodeCaveFinder.CodeCaveWindow()
    window.Show("Spelunky")

def neuter():
    global ftl
    ftl.neuter()

def showhelp():

    api = ""
    ea = ScreenEA()
    mnem = GetMnem(ea)
    optype1 = GetOpType(ea,0)
    optype2 = GetOpType(ea,1)
    op1 = GetOpnd(ea,0)
    op2 = GetOpnd(ea,1)

    if mnem != "call" and mnem != "mov" and mnem != "jmp":
        print ("Invalid mnem (%s)!" %mnem)
        return

    if optype2 !=0:
        if optype1 == 1 and optype2 == 2:
            api = op2
        else:
            print ("No valid instruction operands combination!")
            return
    else:
        if (optype1 == 7 or optype1 == 2):
            api = op1
        else:
            print ("Invalid API call!")
            return
            
    if api.find("sub_") == 0 or api.find("loc_") == 0:
        print ("Invalid API call!")
        return

    if api.find("ds:") == 0:
        api = api[3:]
    if api.find("__imp_") == 0:
        api = api[6:]
    if api.find("j_") == 0:
        api = api[2:]
    if api[-1] == 'W' or api[-1] == 'A':
        api = api[:-1]

    winhlp = os.path.join(os.path.expandvars("%SystemRoot%"), "winhlp32.exe")
    htmlhlp = os.path.join(os.path.expandvars("%SystemRoot%"), "hh.exe")

    if os.path.isfile(htmlhlp) and os.access(htmlhlp, os.R_OK):
        hh = "start /B " + htmlhlp
        hlpapi = ""
        helpfile = idadir("") + '\\helps\\Reconst-PSDKHLP.chm'

        if not os.path.isfile(helpfile):
            Warning("Can't find %s! Must be in the same dir as IDAAPIHelp.py!" % helpfile)
            return 
        hlpapi = hh + " " + helpfile + "::/" + api + ".htm"
        Exec(hlpapi)
    else:
        if os.path.isfile(winhlp) and os.access(winhlp, os.R_OK):
            hh = "start /B " + winhlp
            helpfile = idadir("") + '\\helps\\win32.hlp'
            if not os.path.isfile(helpfile):
                Warning("Can't find %s! Must be in the same dir as IDAAPIHelp.py!" % helpfile)
                return
            hlpapi = hh + " -k" + api + " " + helpfile
            Exec(hlpapi)


icons_path = os.path.join(idc.GetIdaDirectory(), 'plugins', 'FentanylCore', 'icons')

class FentanylReplaceWithNopsHandler(ActionHandler):
    TEXT = "Replace with nops"
    ICON = idaapi.load_custom_icon(os.path.join(icons_path, 'nopout.png'))
    def _activate(self, ctx):
        nopout()


class FentanylNopsAllXrefsHandler(ActionHandler):
    TEXT = "Nops all Xrefs"
    ICON = idaapi.load_custom_icon(os.path.join(icons_path, 'nopxrefs.png'))
    def _activate(self, ctx):
        nopxrefs()

class FentanylAssembleHandler(ActionHandler):
    TEXT = "Assemble"
    ICON = idaapi.load_custom_icon(os.path.join(icons_path, 'assemble.png'))
    def _activate(self, ctx):
        assemble_()

class FentanylToggleJumpHandler(ActionHandler):
    TEXT = "Toggle jump"
    ICON = idaapi.load_custom_icon(os.path.join(icons_path, 'togglejump.png'))
    def _activate(self, ctx):
        togglejump()

class FentanylForceJumpHandler(ActionHandler):
    TEXT = "Force jump"
    ICON = idaapi.load_custom_icon(os.path.join(icons_path, 'uncondjump.png'))
    def _activate(self, ctx):
        uncondjump()


class FentanylUndoPatchHandler(ActionHandler):
    TEXT = "Undo Patch"
    ICON = idaapi.load_custom_icon(os.path.join(icons_path, 'undo.png'))
    def _activate(self, ctx):
        undo()

class FentanylRedoPatchHandler(ActionHandler):
    TEXT = "Redo Patch"
    ICON = idaapi.load_custom_icon(os.path.join(icons_path, 'redo.png'))
    def _activate(self, ctx):
        redo()

class FentanylSaveFileHandler(ActionHandler):
    TEXT = "Save patched file ..."
    ICON = idaapi.load_custom_icon(os.path.join(icons_path, 'save.png'))
    def _activate(self, ctx):
        fentanyl_savefile()

class FentanylFindCodeCavesHandler(ActionHandler):
    TEXT = "Find Code Caves ..."
    ICON = idaapi.load_custom_icon(os.path.join(icons_path, 'find.png'))
    def _activate(self, ctx):
        openspelunky()

class FentanylShowAPIHelpHandler(ActionHandler):
    TEXT = "Show API Help ..."
    ICON = idaapi.load_custom_icon(os.path.join(icons_path, 'apifind.png'))
    def _activate(self, ctx):
        showhelp()

class Hooks(idaapi.UI_Hooks):
    def populating_tform_popup(self, form, popup):
        # You can attach here.
        pass

    def finish_populating_tform_popup(self, form, popup):
        # Or here, after the popup is done being populated by its owner.

        if idaapi.get_tform_type(form) == idaapi.BWN_DISASM:
            idaapi.attach_action_to_popup(form, popup, FentanylReplaceWithNopsHandler.get_name(), "Code patch/")
            idaapi.attach_action_to_popup(form, popup, FentanylNopsAllXrefsHandler.get_name(), "Code patch/")
            idaapi.attach_action_to_popup(form, popup, FentanylAssembleHandler.get_name(), "Code patch/")
            idaapi.attach_action_to_popup(form, popup, FentanylToggleJumpHandler.get_name(), "Code patch/")
            idaapi.attach_action_to_popup(form, popup, FentanylForceJumpHandler.get_name(), "Code patch/")
            idaapi.attach_action_to_popup(form, popup, FentanylUndoPatchHandler.get_name(), "Code patch/")
            idaapi.attach_action_to_popup(form, popup, FentanylRedoPatchHandler.get_name(), "Code patch/")
            idaapi.attach_action_to_popup(form, popup, FentanylFindCodeCavesHandler.get_name(), "Code patch/")
            idaapi.attach_action_to_popup(form, popup, FentanylShowAPIHelpHandler.get_name(), "Code patch/")
            idaapi.attach_action_to_popup(form, popup, FentanylSaveFileHandler.get_name(), "Code patch/")


#--------------------------------------------------------------------------
# Plugin
#--------------------------------------------------------------------------
class fentany_t(plugin_t):
    flags = idaapi.PLUGIN_UNL
    comment = "Enhances manipulation and application of patched bytes."
    help = "Enhances manipulation and application of patched bytes."
    wanted_name = "Fentany IDA Patcher"
    wanted_hotkey = ""

    def init(self):

        if not idaapi.is_idaq():
            return PLUGIN_SKIP
        # We need to use some global val

        global ftl_path, asf, ftl, ftln, hack

        if not 'ftl_path' in globals():
            ftl_path = os.path.join(idc.GetIdaDirectory(), 'plugins')

        if not 'asf' in globals():
            asf = AssembleForm.AssembleForm()

        if not 'ftl' in globals():
            ftl = Fentanyl.Fentanyl() # Init Fentanyl Class

        if not 'ftln' in globals():
            ftln = Neuter.Neuter(ftl) # Init Newter Class

        #XXX: Store the parents of the QWidgets. Otherwise, some get GCed.
        if not 'hack' in globals():
            hack = []
        FentanylReplaceWithNopsHandler.register()
        FentanylNopsAllXrefsHandler.register()
        FentanylAssembleHandler.register()
        FentanylToggleJumpHandler.register()
        FentanylForceJumpHandler.register()
        FentanylUndoPatchHandler.register()
        FentanylRedoPatchHandler.register()
        FentanylSaveFileHandler.register()
        FentanylFindCodeCavesHandler.register()
        FentanylShowAPIHelpHandler.register()

        self.hooks = Hooks()
        self.hooks.hook()
        return idaapi.PLUGIN_KEEP

    def term(self):
        FentanylReplaceWithNopsHandler.unregister()
        FentanylNopsAllXrefsHandler.unregister()
        FentanylAssembleHandler.unregister()
        FentanylToggleJumpHandler.unregister()
        FentanylForceJumpHandler.unregister()
        FentanylUndoPatchHandler.unregister()
        FentanylRedoPatchHandler.unregister()
        FentanylSaveFileHandler.unregister()
        FentanylFindCodeCavesHandler.unregister()
        FentanylShowAPIHelpHandler.unregister()


    def run(self, arg):
        pass

    # End of IDA >= 6.7 Code
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#---------------------------------------------------------------------
# Init Plugin
#---------------------------------------------------------------------
def PLUGIN_ENTRY():
    return fentany_t()
